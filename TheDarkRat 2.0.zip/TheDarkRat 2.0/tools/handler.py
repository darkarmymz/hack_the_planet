#!/usr/bin/python
from time import sleep
from os import system
import socket
import sys

system('clear')
print (''' 

        ,----,                                                                                                 
      ,/   .`|                                                                                                 
    ,`   .'  :  ,---,                  ,---,                              ,-.,-.----.                  ___     
  ;    ;     /,--.' |                .'  .' `\                        ,--/ /|\    /  \               ,--.'|_   
.'___,/    ,' |  |  :              ,---.'     \              __  ,-.,--. :/ |;   :    \              |  | :,'  
|    :     |  :  :  :              |   |  .`\  |           ,' ,'/ /|:  : ' / |   | .\ :              :  : ' :  
;    |.';  ;  :  |  |,--.   ,---.  :   : |  '  |  ,--.--.  '  | |' ||  '  /  .   : |: |   ,--.--.  .;__,'  /   
`----'  |  |  |  :  '   |  /     \ |   ' '  ;  : /       \ |  |   ,''  |  :  |   |  \ :  /       \ |  |   |    
    '   :  ;  |  |   /' : /    /  |'   | ;  .  |.--.  .-. |'  :  /  |  |   \ |   : .  / .--.  .-. |:__,'| :      2.0    
    |   |  '  '  :  | | |.    ' / ||   | :  |  ' \__\/: . .|  | '   '  : |. \;   | |  \  \__\/: . .  '  : |__  
    '   :  |  |  |  ' | :'   ;   /|'   : | /  ;  ," .--.; |;  : |   |  | ' \ \   | ;\  \ ," .--.; |  |  | '.'| 
    ;   |.'   |  :  :_:,''   |  / ||   | '` ,/  /  /  ,.  ||  , ;   '  : |--':   ' | \.'/  /  ,.  |  ;  :    ; 
    '---'     |  | ,'    |   :    |;   :  .'   ;  :   .'   \---'    ;  |,'   :   : :-' ;  :   .'   \ |  ,   /  
              `--''       \   \  / |   ,.'     |  ,     .-./        '--'     |   |.'   |  ,     .-./  ---`-'   
                           `----'  '---'        `--`---'                     `---'      `--`---'               
                     Telegram: @un00mz - Darkarmy | Handler                              	  ''')
print ("___________________________________________________________________________________________________________________________________________")
print ("")
ngr = raw_input("Deseja usar Endereco do Ngrok ? (sim/nao) > ")
opc1 = 'sim'
opc2 = 'nao'
if ngr == opc1:
		ip = raw_input("IP do Ngrok > ")
		porta = input ("  PORTA > ")
		print ("")
		print ("  Aguardando Conexao...")
		sleep(10)
		system('sudo nc %(ip)s -vlp %(porta)s ' % locals())

if ngr == opc2:
	ip2 = raw_input("IP reverso > ")
	porta = input ("  PORTA > ")
	print ("")
	print ("  Aguardando Conexao...")
	sleep(10)
	system('sudo nc %(ip2)s -vlp %(porta)s ' % locals())	




	
	
