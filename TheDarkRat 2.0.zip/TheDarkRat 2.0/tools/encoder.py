#!/usr/bin/python
from os import system
import os
import subprocess


print("")
system('sudo apt-get install wine32')
system('sudo apt-get install shellter')
system("clear")
system('sudo shellter')
		


		
