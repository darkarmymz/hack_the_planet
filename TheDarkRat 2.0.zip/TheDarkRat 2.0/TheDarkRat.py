#!/usr/bin/python
# Backdoor Automatization
#
# by: Darkarmy
# version: 2.0
# Language: python
# 
############################

from time import sleep
from os import system

print ('''
        ,----,                                                                                                 
      ,/   .`|                                                                                                 
    ,`   .'  :  ,---,                  ,---,                              ,-.,-.----.                  ___     
  ;    ;     /,--.' |                .'  .' `\                        ,--/ /|\    /  \               ,--.'|_   
.'___,/    ,' |  |  :              ,---.'     \              __  ,-.,--. :/ |;   :    \              |  | :,'  
|    :     |  :  :  :              |   |  .`\  |           ,' ,'/ /|:  : ' / |   | .\ :              :  : ' :  
;    |.';  ;  :  |  |,--.   ,---.  :   : |  '  |  ,--.--.  '  | |' ||  '  /  .   : |: |   ,--.--.  .;__,'  /   
`----'  |  |  |  :  '   |  /     \ |   ' '  ;  : /       \ |  |   ,''  |  :  |   |  \ :  /       \ |  |   |    
    '   :  ;  |  |   /' : /    /  |'   | ;  .  |.--.  .-. |'  :  /  |  |   \ |   : .  / .--.  .-. |:__,'| :         2.0    
    |   |  '  '  :  | | |.    ' / ||   | :  |  ' \__\/: . .|  | '   '  : |. \;   | |  \  \__\/: . .  '  : |__  
    '   :  |  |  |  ' | :'   ;   /|'   : | /  ;  ," .--.; |;  : |   |  | ' \ \   | ;\  \ ," .--.; |  |  | '.'| 
    ;   |.'   |  :  :_:,''   |  / ||   | '` ,/  /  /  ,.  ||  , ;   '  : |--':   ' | \.'/  /  ,.  |  ;  :    ; 
    '---'     |  | ,'    |   :    |;   :  .'   ;  :   .'   \---'    ;  |,'   :   : :-' ;  :   .'   \ |  ,   /  
              `--''       \   \  / |   ,.'     |  ,     .-./        '--'     |   |.'   |  ,     .-./  ---`-'   
                           `----'  '---'        `--`---'                     `---'      `--`---'               
                     Telegram: @un00mz - Darkarmy | Ferramenta de Criacao Automatizada de Backdoor                                                              ''')
print ("___________________________________________________________________________________________________________________")
print ("")
print ("  1 - Criar Backdoor")
print ("  2 - Handler")
print ("  3 - Contacto")
print ("  4 - Sair")
print ("")
opcao = int(input("  Selecione > "))
nr1 = 1
nr2 = 2
nr3 = 3
nr4 = 4
nr5 = 5
print ("")
print ("")
if opcao == nr1:
			sleep(5)
			system("clear")
			system("python tools/criar.py")



if opcao == nr2:
			system("clear")
			print("  Abrindo o Handler...")
			sleep(5)
			system("python tools/handler.py")
			
if opcao == nr3:
			sleep(3)
			system("cat tools/Contato.txt")


if opcao == nr4:
			print("  Saindo...")
			sleep(5)				
			system("exit")						
			
